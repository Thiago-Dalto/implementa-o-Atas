package com.sesi.ImplementAtas;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ImplementAtasApplicationTests {

	@Test
	void contextLoads() {
	}

}
